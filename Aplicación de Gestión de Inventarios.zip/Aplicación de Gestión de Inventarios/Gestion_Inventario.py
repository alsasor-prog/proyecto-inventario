import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QListWidget, QLabel, QGroupBox, QRadioButton, QInputDialog, QMessageBox
from PyQt5.QtGui import QFont, QFontDatabase
import openpyxl
import os

class GestionInventarioApp(QWidget):
    def __init__(self):
        super().__init__()

        # Cargar fuente moderna (Roboto)
        self.font_roboto = QFont("Roboto", 12)

        self.setWindowTitle("Gestión de Inventario")
        self.setGeometry(100, 100, 1310, 700)

        self.productos = []  # Lista de productos en inventario
        self.carrito = []  # Carrito de productos para la venta

        self.id_producto = 1

        self.initUI()
        self.cargar_productos()  # Cargar productos desde Excel

    def initUI(self):
        layout = QVBoxLayout()
        horizontal_layout = QHBoxLayout()

        # Establecer el fondo gris suave de la ventana
        self.setStyleSheet("background-color: #f0f0f0;")

        # Panel Inventario
        self.panel_inventario = QGroupBox("Inventario")
        panel_inventario_layout = QVBoxLayout()

        self.listbox_inventario = QListWidget()
        self.listbox_inventario.setFont(self.font_roboto)
        panel_inventario_layout.addWidget(self.listbox_inventario)

        self.nombre_producto = QLineEdit(self)
        self.nombre_producto.setFont(self.font_roboto)
        self.precio_producto = QLineEdit(self)
        self.precio_producto.setFont(self.font_roboto)
        self.cantidad_producto = QLineEdit(self)
        self.cantidad_producto.setFont(self.font_roboto)
        self.stock_minimo_producto = QLineEdit(self)
        self.stock_minimo_producto.setFont(self.font_roboto)

        panel_inventario_layout.addWidget(QLabel("Nombre del Producto:"))
        panel_inventario_layout.addWidget(self.nombre_producto)
        panel_inventario_layout.addWidget(QLabel("Precio del Producto:"))
        panel_inventario_layout.addWidget(self.precio_producto)
        panel_inventario_layout.addWidget(QLabel("Cantidad del Producto:"))
        panel_inventario_layout.addWidget(self.cantidad_producto)
        panel_inventario_layout.addWidget(QLabel("Stock Mínimo:"))
        panel_inventario_layout.addWidget(self.stock_minimo_producto)

        # Botón Agregar Producto (Botón Azul)
        self.boton_agregar_producto = QPushButton("Agregar Producto", self)
        self.boton_agregar_producto.setFont(self.font_roboto)
        self.boton_agregar_producto.setStyleSheet("background-color: #007BFF; color: white;")
        self.boton_agregar_producto.clicked.connect(self.agregar_producto)
        panel_inventario_layout.addWidget(self.boton_agregar_producto)

        # Botón Eliminar Producto (Botón Rojo)
        self.boton_eliminar_inventario = QPushButton("Eliminar Producto del Inventario", self)
        self.boton_eliminar_inventario.setFont(self.font_roboto)
        self.boton_eliminar_inventario.setStyleSheet("background-color: #DC3545; color: white;")
        self.boton_eliminar_inventario.clicked.connect(self.eliminar_del_inventario)
        panel_inventario_layout.addWidget(self.boton_eliminar_inventario)

        self.panel_inventario.setLayout(panel_inventario_layout)

        # Panel Carrito
        self.panel_venta = QGroupBox("Carrito de Venta")
        panel_venta_layout = QVBoxLayout()

        self.listbox_venta = QListWidget()
        self.listbox_venta.setFont(self.font_roboto)
        panel_venta_layout.addWidget(self.listbox_venta)

        self.panel_venta.setLayout(panel_venta_layout)

        # Botones entre inventario y carrito
        botones_intermedios_layout = QVBoxLayout()

        # Agregamos espacios para centrar las flechas verticalmente
        botones_intermedios_layout.addStretch()

        # Flecha de agregar al carrito
        self.boton_agregar_carrito = QPushButton("→", self)
        self.boton_agregar_carrito.setFont(QFont("Roboto", 36))
        self.boton_agregar_carrito.setStyleSheet("font-size: 40px;")  # Ajustar tamaño de la flecha
        self.boton_agregar_carrito.clicked.connect(self.agregar_al_carrito)
        botones_intermedios_layout.addWidget(self.boton_agregar_carrito)

        # Flecha de devolver al inventario
        self.boton_devolver_inventario = QPushButton("←", self)
        self.boton_devolver_inventario.setFont(QFont("Roboto", 36))
        self.boton_devolver_inventario.setStyleSheet("font-size: 40px;")  # Ajustar tamaño de la flecha
        self.boton_devolver_inventario.clicked.connect(self.devolver_al_inventario)
        botones_intermedios_layout.addWidget(self.boton_devolver_inventario)

        # Añadimos un espacio para que las flechas estén centradas en la mitad de la sección
        botones_intermedios_layout.addStretch()

        # Agregar secciones al layout principal
        horizontal_layout.addWidget(self.panel_inventario)
        horizontal_layout.addLayout(botones_intermedios_layout)
        horizontal_layout.addWidget(self.panel_venta)
        layout.addLayout(horizontal_layout)

        # Panel Total
        self.panel_total = QGroupBox("Total de Venta")
        panel_total_layout = QVBoxLayout()

        self.total_label = QLabel("Total: $ 0")  # Espacio agregado después del signo $
        self.iva_label = QLabel("IVA (19%): $ 0")  # Espacio agregado después del signo $
        self.total_iva_label = QLabel("Total con IVA: $ 0")  # Espacio agregado después del signo $
        self.total_label.setFont(QFont("Roboto", 16))
        self.iva_label.setFont(QFont("Roboto", 16))
        self.total_iva_label.setFont(QFont("Roboto", 16))

        panel_total_layout.addWidget(self.total_label)
        panel_total_layout.addWidget(self.iva_label)
        panel_total_layout.addWidget(self.total_iva_label)

        self.radio_efectivo = QRadioButton("Efectivo")
        self.radio_tarjeta = QRadioButton("Tarjeta")
        self.radio_efectivo.setFont(self.font_roboto)
        self.radio_tarjeta.setFont(self.font_roboto)

        panel_total_layout.addWidget(self.radio_efectivo)
        panel_total_layout.addWidget(self.radio_tarjeta)

        # Botón Confirmar Venta (Botón Verde)
        self.boton_confirmar_total = QPushButton("Confirmar Venta", self)
        self.boton_confirmar_total.setFont(self.font_roboto)
        self.boton_confirmar_total.setStyleSheet("background-color: #28A745; color: white;")  # Botón verde
        self.boton_confirmar_total.clicked.connect(self.confirmar_venta)
        panel_total_layout.addWidget(self.boton_confirmar_total)

        self.panel_total.setLayout(panel_total_layout)
        layout.addWidget(self.panel_total)

        self.setLayout(layout)

    def cargar_productos(self):
        """Carga los productos desde un archivo de Excel"""
        try:
            # Obtenemos la ruta del archivo en la misma carpeta donde se encuentra el script
            file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "productos.xlsx")

            if os.path.exists(file_path):
                wb = openpyxl.load_workbook(file_path)
                sheet = wb.active
                for row in sheet.iter_rows(min_row=2, values_only=True):  # Comienza desde la fila 2
                    producto = {
                        "id": row[0],
                        "nombre": row[1],
                        "precio": row[2],
                        "cantidad": row[3],
                        "stock_minimo": row[4] if len(row) > 4 else 0  # Cargar stock mínimo si existe
                    }
                    self.productos.append(producto)
                    self.listbox_inventario.addItem(f"ID: {row[0]} - {row[1]} - ${row[2]} - Cantidad: {row[3]}")
            else:
                self.show_message("Aviso", "El archivo 'productos.xlsx' no existe en la carpeta del script.")
                self.crear_excel()
        except Exception as e:
            self.show_message("Error", f"Error al cargar productos: {str(e)}")

    def crear_excel(self):
        """Crea el archivo de Excel si no existe"""
        try:
            # Obtenemos la ruta del archivo en la misma carpeta donde se encuentra el script
            file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "productos.xlsx")
            
            wb = openpyxl.Workbook()
            sheet = wb.active
            sheet.title = "Productos"
            sheet.append(["ID", "Nombre", "Precio", "Cantidad", "Stock Mínimo"])  # Encabezados

            wb.save(file_path)
            self.show_message("Aviso", "El archivo 'productos.xlsx' ha sido creado.")
        except Exception as e:
            self.show_message("Error", f"Error al crear el archivo de Excel: {str(e)}")

    def guardar_productos(self, show_success_message=False):
        """Guarda los productos en un archivo de Excel en la misma carpeta que el script"""
        try:
            file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "productos.xlsx")

            wb = openpyxl.Workbook()
            sheet = wb.active
            sheet.title = "Productos"
            sheet.append(["ID", "Nombre", "Precio", "Cantidad", "Stock Mínimo"])  # Encabezados

            for producto in self.productos:
                sheet.append([producto["id"], producto["nombre"], producto["precio"], producto["cantidad"], producto["stock_minimo"]]) # Guardar stock mínimo

            wb.save(file_path)

            if show_success_message:
                self.show_message("Éxito", "Productos guardados correctamente.")
        except Exception as e:
            self.show_message("Error", f"Error al guardar productos: {str(e)}")

    def agregar_producto(self):
        nombre = self.nombre_producto.text()
        try:
            precio = float(self.precio_producto.text())
            cantidad = int(self.cantidad_producto.text())
            stock_minimo = int(self.stock_minimo_producto.text())
        except ValueError:
            self.show_message("Error", "Precio, cantidad o stock mínimo no válidos.")
            return
        
        producto = {"id": self.id_producto, "nombre": nombre, "precio": precio, "cantidad": cantidad, "stock_minimo": stock_minimo}
        self.productos.append(producto)
        self.listbox_inventario.addItem(f"ID: {self.id_producto} - {nombre} - ${precio} - Cantidad: {cantidad}")
        self.id_producto += 1

        self.nombre_producto.clear()
        self.precio_producto.clear()
        self.cantidad_producto.clear()
        self.stock_minimo_producto.clear()  # Limpiar el campo de stock mínimo

        # Guardar los productos y mostrar mensaje de éxito
        self.guardar_productos(show_success_message=True)

    def eliminar_del_inventario(self):
        selected_items = self.listbox_inventario.selectedItems()
        if not selected_items:
            self.show_message("Error", "Selecciona un producto del inventario para eliminar.")
            return

        item_text = selected_items[0].text()
        print(f"Texto del item seleccionado: {item_text}")  # Imprime para depuración

        try:
            import re
            match = re.search(r"ID:\s*(\d+)", item_text)  # Busca el número después de "ID:"
            if match:
                producto_id = int(match.group(1))  # Extraemos el ID como número
                print(f"ID del producto extraído: {producto_id}")  # Imprime para depuración
            else:
                raise ValueError("No se encontró un ID válido en el texto del producto.")

            producto = next((item for item in self.productos if item["id"] == producto_id), None)

            if producto:
                print(f"Producto encontrado: {producto}")  # Imprime para depuración
                self.productos.remove(producto)
                self.listbox_inventario.takeItem(self.listbox_inventario.row(selected_items[0]))

                # Llamar a guardar_productos sin mostrar el mensaje de éxito
                self.guardar_productos(show_success_message=False)

                # Mostrar solo el mensaje de eliminación
                self.show_message("Éxito", "Producto eliminado con éxito.")
            else:
                self.show_message("Error", "Producto no encontrado.")
        except IndexError:
            self.show_message("Error", "No se pudo obtener el ID del producto. El formato del producto es incorrecto.")
        except ValueError as ve:
            self.show_message("Error", str(ve))

    def agregar_al_carrito(self):
        selected_items = self.listbox_inventario.selectedItems()
        if not selected_items:
            self.show_message("Error", "Selecciona un producto del inventario para agregar al carrito.")
            return

        item_text = selected_items[0].text()
        try:
            producto_id = int(item_text.split(" - ")[0].split(":")[1].strip())
            producto = next((item for item in self.productos if item["id"] == producto_id), None)

            if producto:
                cantidad_a_agregar, ok = QInputDialog.getInt(
                    self, "Cantidad", f"¿Cuántos deseas agregar (max {producto['cantidad']})?", 1, 1, producto["cantidad"], 1
                )
                if ok:
                    # Reducir cantidad en inventario
                    producto["cantidad"] -= cantidad_a_agregar
                    if producto["cantidad"] == 0:
                        # Si el producto se agota, eliminarlo del inventario lógico y visual
                        self.productos.remove(producto)
                        self.listbox_inventario.takeItem(self.listbox_inventario.row(selected_items[0]))
                    else:
                        # Actualizar visualmente el inventario
                        selected_items[0].setText(
                            f"ID: {producto['id']} - {producto['nombre']} - ${producto['precio']} - Cantidad: {producto['cantidad']}"
                        )

                    # Verificar si el stock ha llegado al mínimo
                    if producto["cantidad"] <= producto["stock_minimo"] and producto["cantidad"] >= 0:
                        self.show_message("Aviso", f"El stock del producto '{producto['nombre']}' ha llegado al mínimo.")

                    # Agregar al carrito (o actualizar si ya existe)
                    carrito_item = next((item for item in self.carrito if item["id"] == producto_id), None)
                    if carrito_item:
                        carrito_item["cantidad"] += cantidad_a_agregar
                        # Actualizar visualmente el carrito
                        for i in range(self.listbox_venta.count()):
                            if f"{carrito_item['nombre']} - ${carrito_item['precio']}" in self.listbox_venta.item(i).text():
                                self.listbox_venta.item(i).setText(
                                    f"{carrito_item['nombre']} - ${carrito_item['precio']} - Cantidad: {carrito_item['cantidad']}"
                                )
                                break
                    else:
                        # Nuevo producto en el carrito
                        self.carrito.append({
                            "id": producto["id"],
                            "nombre": producto["nombre"],
                            "precio": producto["precio"],
                            "cantidad": cantidad_a_agregar
                        })
                        self.listbox_venta.addItem(
                            f"{producto['nombre']} - ${producto['precio']} - Cantidad: {cantidad_a_agregar}"
                        )

                    self.mostrar_total()
        except Exception as e:
            self.show_message("Error", f"Error al agregar al carrito: {str(e)}")

    def devolver_al_inventario(self):
        selected_items = self.listbox_venta.selectedItems()
        if not selected_items:
            self.show_message("Error", "Selecciona un producto del carrito para devolver al inventario.")
            return

        item_text = selected_items[0].text()
        try:
            producto_nombre = item_text.split(" - ")[0]
            producto_carrito = next((item for item in self.carrito if item["nombre"] == producto_nombre), None)

            if producto_carrito:
                cantidad_a_devolver, ok = QInputDialog.getInt(
                    self, "Cantidad", f"¿Cuántos deseas devolver (max {producto_carrito['cantidad']})?", 1, 1, producto_carrito["cantidad"], 1
                )
                if ok:
                    producto_carrito["cantidad"] -= cantidad_a_devolver
                    if producto_carrito["cantidad"] == 0:
                        # Si se vacía, eliminar del carrito lógico y visual
                        self.carrito.remove(producto_carrito)
                        self.listbox_venta.takeItem(self.listbox_venta.row(selected_items[0]))
                    else:
                        # Actualizar visualmente el carrito
                        selected_items[0].setText(
                            f"{producto_carrito['nombre']} - ${producto_carrito['precio']} - Cantidad: {producto_carrito['cantidad']}"
                        )

                    # Agregar de vuelta al inventario (o actualizar si ya existe)
                    inventario_item = next((item for item in self.productos if item["id"] == producto_carrito["id"]), None)
                    if inventario_item:
                        inventario_item["cantidad"] += cantidad_a_devolver
                        for i in range(self.listbox_inventario.count()):
                            if f"ID: {inventario_item['id']}" in self.listbox_inventario.item(i).text():
                                self.listbox_inventario.item(i).setText(
                                    f"ID: {inventario_item['id']} - {inventario_item['nombre']} - ${inventario_item['precio']} - Cantidad: {inventario_item['cantidad']}"
                                )
                                break
                                
                        # Verificar si el stock ha llegado al mínimo
                        if inventario_item["cantidad"] <= inventario_item["stock_minimo"] and inventario_item["cantidad"] >= 0:
                            self.show_message("Aviso", f"El stock del producto '{inventario_item['nombre']}' ha llegado al mínimo.")

                    else:
                        # Nuevo producto en el inventario
                        self.productos.append({
                            "id": producto_carrito["id"],
                            "nombre": producto_carrito["nombre"],
                            "precio": producto_carrito["precio"],
                            "cantidad": cantidad_a_devolver,
                            "stock_minimo": 0  # Agregar stock mínimo si es relevante
                        })
                        self.listbox_inventario.addItem(
                            f"ID: {producto_carrito['id']} - {producto_carrito['nombre']} - ${producto_carrito['precio']} - Cantidad: {cantidad_a_devolver}"
                        )

                    self.mostrar_total()
        except Exception as e:
            self.show_message("Error", f"Error al devolver al inventario: {str(e)}")

    def confirmar_venta(self):
        if not self.carrito:
            self.show_message("Error", "El carrito está vacío. Agrega productos antes de confirmar la venta.")
            return

        total = sum(item['precio'] * item['cantidad'] for item in self.carrito)
        iva = total * 0.19
        total_con_iva = total + iva

        metodo_pago = "Efectivo" if self.radio_efectivo.isChecked() else "Tarjeta" if self.radio_tarjeta.isChecked() else None

        if not metodo_pago:
            self.show_message("Error", "Selecciona un método de pago.")
            return

        # Crear el cuadro de diálogo personalizado con el botón "Cancelar Venta"
        msg = QMessageBox()
        msg.setWindowTitle("Confirmar Venta")
        msg.setText(f"Total con IVA: $ {round(total_con_iva)}\nMétodo de Pago: {metodo_pago}")
        msg.setIcon(QMessageBox.Information)

        btn_ok = msg.addButton("Aceptar", QMessageBox.AcceptRole)
        btn_cancel = msg.addButton("Cancelar Venta", QMessageBox.RejectRole)

        msg.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: black;
            }
            QPushButton {
                background-color: #007BFF;
                color: white;
                font-size: 12px;
            }
        """)

        msg.exec_()

        if msg.clickedButton() == btn_ok:
            self.carrito.clear()
            self.listbox_venta.clear()
            self.mostrar_total()
            self.show_message("Venta Confirmada", "Gracias por tu compra.")
        elif msg.clickedButton() == btn_cancel:
            self.cancelar_venta()

    def cancelar_venta(self):
        # Devolver los productos del carrito al inventario
        for item in self.carrito:
            # Buscar el producto en el inventario por su ID
            producto = next((p for p in self.productos if p["id"] == item["id"]), None)
            
            if producto:
                # Si el producto existe en el inventario, sumamos la cantidad
                producto["cantidad"] += item["cantidad"]
                # Actualizamos la interfaz del inventario con la nueva cantidad
                for index in range(self.listbox_inventario.count()):
                    list_item = self.listbox_inventario.item(index)
                    # Comprobamos si el ID coincide con el producto en la lista
                    if f"ID: {producto['id']}" in list_item.text():
                        list_item.setText(f"ID: {producto['id']} - {producto['nombre']} - ${producto['precio']} - Cantidad: {producto['cantidad']}")
                        break
            else:
                # Si no existe en el inventario (por alguna razón), agregamos el producto de nuevo
                self.productos.append({
                    "id": item["id"],
                    "nombre": item["nombre"],
                    "precio": item["precio"],
                    "cantidad": item["cantidad"]
                })
                # También lo agregamos a la interfaz del inventario
                self.listbox_inventario.addItem(f"ID: {item['id']} - {item['nombre']} - ${item['precio']} - Cantidad: {item['cantidad']}")

        # Limpiar el carrito y la lista de venta
        self.carrito.clear()
        self.listbox_venta.clear()

        # Actualizar el total
        self.mostrar_total()

        # Mostrar un mensaje de confirmación
        self.show_message("Venta Cancelada", "Los productos han sido devueltos al inventario.")

    def mostrar_total(self):
        total = sum(item['precio'] * item['cantidad'] for item in self.carrito)
        self.total_label.setText(f"Total: $ {round(total)}")  # Espacio agregado después del signo $
        iva = total * 0.19
        self.iva_label.setText(f"IVA (19%): $ {round(iva)}")  # Espacio agregado después del signo $
        total_con_iva = total + iva
        self.total_iva_label.setText(f"Total con IVA: $ {round(total_con_iva)}")  # Espacio agregado después del signo $

    def show_message(self, title, message):
        msg = QMessageBox()
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setIcon(QMessageBox.Information)
        msg.exec_()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = GestionInventarioApp()
    window.show()
    sys.exit(app.exec_())
